package com.example.studentdetails

data class Student(val name: String, val rollNumber: String, val age: Int, var deleted: Boolean = false)

